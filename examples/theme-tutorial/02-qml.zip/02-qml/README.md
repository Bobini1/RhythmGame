# 02-qml

Copy the whole `02-qml` directory into your game's `themes` directory and restart the game.
In Settings > Themes, choose `02-qml` for the screens listed in `theme.json`.
Keep Default selected for screens the example does not provide.

Read the lesson
at [the tutorial source](https://github.com/Bobini1/RhythmGame/blob/master/docs/pages/theme-tutorial/02-qml.md).
The generated tutorial includes the code snippets and a ZIP download of this directory.

The examples use the theme API in the same source revision as the tutorial.
